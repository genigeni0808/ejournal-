# ejournal-
a simple ejournal website
